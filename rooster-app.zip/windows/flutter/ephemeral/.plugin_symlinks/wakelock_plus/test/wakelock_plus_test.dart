import 'package:flutter_test/flutter_test.dart';

void main() {
  // There are no unit tests here as the API in this package only forwards the
  // calls to the platform interface (unit tested) → platform implementations.
  // Instead, this is all tested via e2e tests in the integration tests in the
  // example app.
  test('no unit tests', () {});
}
