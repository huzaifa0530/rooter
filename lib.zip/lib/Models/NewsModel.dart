import 'dart:convert';

class NewsModel {
  final int id;
  final String title;
  final String description;
  final String imagePath;
  final DateTime publishedAt;
  final List<NewsContent> contentBlocks;
  final List<String> tags;

  String get shortDescription {
    return description.length > 80 ? '${description.substring(0, 80)}...' : description;
  }

  NewsModel({
    required this.id,
    required this.title,
    required this.description,
    required this.imagePath,
    required this.publishedAt,
    required this.contentBlocks,
    required this.tags,
  });

  factory NewsModel.fromJson(Map<String, dynamic> json) {
    return NewsModel(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      imagePath: json['image_path'],
      publishedAt: DateTime.parse(json['published_at']),
      tags: List<String>.from(json['tags'].map((t) => t['name'])),
      contentBlocks: List<NewsContent>.from(
        json['sections'].map((b) => NewsContent.fromJson(b)),
      ),
    );
  }
}

enum ContentType { image, video, text }

class NewsContent {
  final ContentType type;
  final String data;

  NewsContent({required this.type, required this.data});

  factory NewsContent.fromJson(Map<String, dynamic> json) {
    ContentType type = ContentType.text;
    if (json['media_type'] == 'image') {
      type = ContentType.image;
    } else if (json['media_type'] == 'video') {
      type = ContentType.video;
    }

    return NewsContent(
      type: type,
      data: json['media_path'] ?? json['description'] ?? '',
    );
  }
}
