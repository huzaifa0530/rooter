import 'package:get/get.dart';
import 'package:rooster/Models/CourseModel.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CourseController extends GetxController {
  var courses = <CourseModel>[].obs;
  var isLoading = true.obs;

  @override
  void onInit() {
    fetchCourses();
    super.onInit();
  }

  void fetchCourses() async {
    isLoading.value = true;
    try {
      final response = await http.get(Uri.parse('https://test.rubicstechnology.com/api/courses'));
      if (response.statusCode == 200) {
        List data = jsonDecode(response.body);
        courses.value = data.map((e) => CourseModel.fromJson(e)).toList();
      }
    } catch (e) {
      print('Error fetching courses: $e');
    } finally {
      isLoading.value = false;
    }
  }

  int getProgress(String courseTitle) {
    return 20; // fake progress for now
  }
}
